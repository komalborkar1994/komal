package main;

import service.DoctorService;

public class Dectormain {
	public static void main(String[] args) {
		DoctorService doctorService=new DoctorService();
		doctorService.printDentistDetail();
		
		
	}

}
